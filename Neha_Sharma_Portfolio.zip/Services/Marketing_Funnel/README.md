# Marketing Funnel Analytics

**Business Problem**: Track lead conversion effectiveness and cost-efficiency.

**Tools Used**: Tableau, Google Sheets

**Role**: Built a dashboard for a digital agency to monitor CAC, conversion rates, and drop-off.

**Key Insights**:
- Google Ads had lower CAC but lower conversion rate
- Meta Ads converted better in retargeting stages

**Outputs**:
- Funnel dashboard in Tableau
- Campaign strategy recommendations
