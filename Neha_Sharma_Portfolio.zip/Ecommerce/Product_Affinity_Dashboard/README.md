# Product Affinity Dashboard

**Business Problem**: Identify commonly purchased product pairs to drive cross-selling strategies.

**Tools Used**: Tableau, Excel

**Role**: Built a dashboard using synthetic Amazon-style data to visualize product affinities.

**Key Insights**:
- Top combos: Face Wash + Moisturizer, Shampoo + Conditioner
- Suggested product bundling increased simulated sales by 15%

**Outputs**:
- Tableau dashboard visualizing product affinity matrix
- Screenshot and twb file

