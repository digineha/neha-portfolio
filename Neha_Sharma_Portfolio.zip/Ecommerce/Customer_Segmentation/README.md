# Customer Segmentation using RFM

**Business Problem**: Segment customers based on behavior to personalize marketing.

**Tools Used**: Excel, SQL

**Role**: Applied RFM (Recency, Frequency, Monetary) scoring on synthetic data to cluster users.

**Key Insights**:
- 20% of customers contributed 60% of revenue
- High-value customers targeted via email increased conversions

**Outputs**:
- Excel dashboard
- SQL script for RFM segmentation
