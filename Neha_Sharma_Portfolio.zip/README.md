# Neha Sharma's Data Analyst Portfolio

Welcome to my portfolio showcasing hands-on data projects for eCommerce and service-based businesses.
Each folder contains:
- A README with business context
- Visual outputs (Tableau, Excel)
- Supporting SQL or data files

Projects:
- Ecommerce/Product Affinity Dashboard
- Ecommerce/Customer Segmentation
- Services/Marketing Funnel

Contact: digineha.official@gmail.com | [LinkedIn](https://linkedin.com/in/digitalneha)
